import launch
from launch.substitutions import Command, LaunchConfiguration
import launch_ros
import os
import xacro


def generate_launch_description():
    pkgPath = launch_ros.substitutions.FindPackageShare(package='float1').find('float1')
    #process the URDF
    xacro_file = os.path.join(pkgPath,'urdf','float1.urdf.xacro')
    robot_description_config = xacro.process_file(xacro_file)
    params = {'robot_description': robot_description_config.toxml()}

    robot_state_publisher_node =launch_ros.actions.Node(
    package='robot_state_publisher',
	executable='robot_state_publisher',
    output='screen',
    parameters=[params])
    
    
    rviz_node = launch_ros.actions.Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        output='screen'
    )

    return launch.LaunchDescription([

        robot_state_publisher_node,
        rviz_node
    ]) 
