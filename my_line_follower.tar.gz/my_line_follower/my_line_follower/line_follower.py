import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Image
from geometry_msgs.msg import Twist
import cv2
import numpy as np
from cv_bridge import CvBridge

class LineFollower(Node):

    def __init__(self):
        super().__init__('line_follower')
        self.subscription = self.create_subscription(
            Image,
            '/camera/image_raw',  # Replace with your camera topic
            self.image_callback,
            10)
        self.publisher = self.create_publisher(Twist, '/cmd_vel', 10)
        self.bridge = CvBridge()
        self.Kp = 0.005 # Proportional gain (adjust as needed)
        self.Kd = 0.002 # Derivative gain (adjust as needed)
        self.last_error = 0
        self.declare_parameter('Kp', self.Kp)
        self.declare_parameter('Kd', self.Kd)
        self.Kp = self.get_parameter('Kp').value
        self.Kd = self.get_parameter('Kd').value
        self.get_logger().info(f"Kp: {self.Kp}, Kd: {self.Kd}")


    def image_callback(self, msg):
        try:
            cv_image = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        except Exception as e:
            self.get_logger().error(f"Error converting image: {e}")
            return

        # 1. Image Processing
        hsv = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)

        # TODO: Adjust LED values 
        # Define range of LED color in HSV (adjust these values)
        lower_led = np.array([100, 100, 100])  # Example for blue LEDs
        upper_led = np.array([130, 255, 255])
        mask = cv2.inRange(hsv, lower_led, upper_led)

        # Apply morphological operations to remove noise (optional)
        kernel = np.ones((5, 5), np.uint8)
        mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)

        # 2. Find the center of the line
        M = cv2.moments(mask)
        if M["m00"] != 0:
            cX = int(M["m10"] / M["m00"])
            cY = int(M["m01"] / M["m00"])

            # Draw a circle at the center (for visualization)
            cv2.circle(cv_image, (cX, cY), 5, (0, 0, 255), -1)

            # 3. Calculate error and control the robot
            error = cX - cv_image.shape[1] / 2  # Deviation from the center of the image
            derivative = error - self.last_error
            self.last_error = error
            turn_rate = self.Kp * error + self.Kd * derivative  # Implement PID control

            twist = Twist()
            twist.linear.x = 0.2  # Forward speed (adjust as needed)
            twist.angular.z = -float(turn_rate) # Negative because positive error is to the right
            self.publisher.publish(twist)
            #self.get_logger().info(f"Published twist: linear.x={twist.linear.x}, angular.z={twist.angular.z}")
        else:
            # If no line is detected, stop the robot
            twist = Twist()
            self.publisher.publish(twist)
            #self.get_logger().warn("No line detected")

        # Display the resulting frame (for debugging)
        cv2.imshow("Frame", cv_image)
        cv2.imshow("Mask", mask)
        cv2.waitKey(1)

def main(args=None):
    rclpy.init(args=args)
    line_follower = LineFollower()
    rclpy.spin(line_follower)
    line_follower.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()