import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, TextSubstitution
from launch_ros.actions import Node
from ros_gz_bridge.actions import RosGzBridge
from ros_gz_sim.actions import GzServer

model='base.sdf'
world='space_world.sdf'
base_path = get_package_share_directory('base')
model_path = os.path.join(base_path, 'models', model)
config_path = os.path.join(base_path, 'config', 'bridge.yaml')
world_path = os.path.join(base_path, 'worlds', world)

def generate_launch_description():
    
    # Launch the GZ server
    gz_server_action = GzServer(
        world_sdf_file=world_path,
    )

    #Launch the ROS-GZ bridge
    ros_gz_bridge_action = RosGzBridge(
        bridge_name='ros_gz_bridge',
        config_file=config_path,
    )

    #Spawn the robot
    load_nodes = Node(
        package='ros_gz_sim',
        executable='create',
        output='screen',
        parameters=[{'file': model_path,
                     'name': 'base',
                     'z': 0.1,
                     }],
    )

    ld = LaunchDescription()
    ld.add_action(gz_server_action)
    ld.add_action(load_nodes)
    ld.add_action(ros_gz_bridge_action)
    
    return ld