gz topic -t "/model/free_flyer_with_arm/joint_trajectory" -m gz.msgs.JointTrajectory -p '
    joint_names: "arm_base_joint"
    joint_names: "shoulder_pan_joint"
    joint_names: "shoulder_lift_joint"
    joint_names: "elbow_joint"
    joint_names: "wrist_1_joint"
    joint_names: "wrist_2_joint"
    joint_names: "wrist_3_joint"
    points {
      positions: 0.1
      positions: 0.1
      positions: 0.1
      positions: 0.1
      positions: 0.1
      positions: 0.1
      positions: 0.1
      
      time_from_start {
        sec: 0
        nsec: 250000000
      }
    }
    points {
      positions: 0.5
      positions: 0.5
      positions: 0.5
      positions: 0.5
      positions: 0.5
      positions: 0.5
      positions: 0.5
      time_from_start {
        sec: 0
        nsec: 500000000
      }
    }
    points {
      positions: 0.2
      positions: 0.2
      positions: 0.2
      positions: 0.2
      positions: 0.2
      positions: 0.2
      positions: 0.2

      time_from_start {
        sec: 0
        nsec: 750000000
      }
    }
    points {
      positions: 0
      positions: 0
      positions: 0
      positions: 0
      positions: 0
      positions: 0
      positions: 0
      
      time_from_start {
        sec: 1
        nsec: 0
      }
    }'