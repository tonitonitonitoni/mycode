import pybullet
import pybullet_data
physics_client = pybullet.connect(pybullet.GUI)
pybullet.resetSimulation() # Reset the simulation space
pybullet.setAdditionalSearchPath(pybullet_data.getDataPath()) # Add path to necessary data for pybullet
pybullet.setGravity(0.0, 0.0, 0) # Set gravity to zero
time_step = 1./240.
pybullet.setTimeStep(time_step) # Set the elapsed time per step

# Load the floor
plane_id = pybullet.loadURDF("plane.urdf")

# Load the robot
arm_start_pos = [0, 0, .5]  # Set initial position (x, y, z)
arm_start_orientation = pybullet.getQuaternionFromEuler([0, 0, 0])  # Set initial orientation (roll, pitch, yaw)
arm_id = pybullet.loadURDF("ur5base.urdf", arm_start_pos, arm_start_orientation, useFixedBase=True)  # Fix the root link with useFixedBase=True to prevent the robot from falling
# Set the camera position for GUI mode
camera_distance = 1.5
camera_yaw = 180.0  # deg
camera_pitch = -10  # deg
camera_target_position = [0.0, 0.0, 1.0]
pybullet.resetDebugVisualizerCamera(camera_distance, camera_yaw, camera_pitch, camera_target_position)
while True:
    pybullet.stepSimulation()

pybullet.disconnect()